﻿CREATE TABLE funcionario(

id SERIAL,
login VARCHAR,
senha VARCHAR(12),
nome VARCHAR,
portaria VARCHAR,
dataAdmissao DATE,
PRIMARY KEY(id)

);

CREATE TABLE frequencia(

id INTEGER,
data DATE,
turno VARCHAR,
FOREIGN KEY(id) REFERENCES  funcionario(id),
PRIMARY KEY(id)

);

CREATE TABLE operacao_log(
id SERIAL,
operacao VARCHAR,
descricao VARCHAR,
data_operacao DATE,
id_funcionario INTEGER,
PRIMARY KEY (ID))

ALTER TABLE operacao_log alter column data_operacao type timestamp

CREATE TABLE log(

id INTEGER,
operacao VARCHAR,
data DATE,
FOREIGN KEY(id) REFERENCES  funcionario(id),
PRIMARY KEY(id)

);

INSERT INTO funcionario(login, senha, nome, portaria, dataAdmissao) VALUES ('gilmar', '123', 'gilmar moreira', 'PMU102030', '2014-08-20')
INSERT INTO funcionario(login, senha, nome, portaria, dataAdmissao) VALUES ('viviano', '123', 'viviano medeiros', 'PMU111110', '2010-05-30')

INSERT INTO frequencia(id, data, turno) VALUES (1, '2014-02-07', 'manhã')

INSERT INTO log(id, operacao, data) VALUES (1, 'cadastrou novo usuário - gilmar', '2014-02-07')

ALTER TABLE frequencia rename column id to idFrequencia
ALTER TABLE frequencia add Column id serial
ALTER TABLE frequencia add constraint frequenciapk primary key (id)
ALTER TABLE frequencia alter column id serial
ALTER TABLE frequencia add column idFuncionario integer

ALTER TABLE funcionario ADD COLUMN nivelAcesso boolean

SELECT z.dia, z.data, f.nome, f.portaria, z.presenca FROM funcionario f, (frequencia fr join (Select data as dt, Extract('Day' From data) as dia From frequencia where idFuncionario = 13) x ON x.dt = fr.data) z WHERE f.id = z.idFuncionario AND z.idFuncionario = 13 AND z.data between '2014-03-01' AND '2014-03-31' order by z.data asc

 Select data, Extract('Day' From data) From frequencia; 

SELECT * FROM funcionario f, log l WHERE f.id = l.idFuncionario AND l.idFuncionario = 4;

UPDATE funcionario  set nivelAcesso = FALSE where nivelAcesso = TRUE
UPDATE `table` SET `isSuccessful` = 1 WHERE `column` = 'criteria'

UPDATE frequencia set presenca = false where presenca = true

UPDATE funcionario SET login = 'ad', senha = '1', nome = 'ad', portaria = '123', dataAdmissao = '2014-03-25', nivelAcesso = true, salario = 12358 where id = 13

ALTER TABLE frequencia add column presenca boolean

ALTER TABLE funcionario add column salario double precision

ALTER TABLE frequencia add column justificativa varchar

ALTER TABLE funcionario add column salario double precision

SELECT * FROM frequencia WHERE idfuncionario = 3 and data Between '01-02-2014' and '28-02-2014';

SELECT COUNT (data) FROM frequencia WHERE idfuncionario = 3 AND data BETWEEN '01-02-2014' AND '28-02-2014' AND presenca = FALSE;

SELECT max(data) FROM frequencia WHERE idFuncionario = 3;

ALTER TABLE funcionario ADD CONSTRAINT nome_funcionario_unique UNIQUE (login);

SELECT COUNT(login) from funcionario where login = 'lulina'